<?php

class WPBakeryShortCode_VC_Gmaps extends WPBakeryShortCode {
}

class WPBakeryShortCode_Nectar_Gmap extends WPBakeryShortCode {
}